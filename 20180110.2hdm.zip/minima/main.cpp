#include <iostream>
#include <fstream>
#include <cmath>
#include "expression.h"
#include "basis-convert.h"
#include "V.h"
#include <vector>
#include <string>

using namespace std;

double ABCEmin(double m112,double m122,double m222,double L1,double L2,double L3,double L4,double L5,double L6,double L7)
{
    double q1,q2,q3,q4;
    double Vmin,Vmin2;
    bool existQ;
//    m112=0.1; m122=0.2;m222= 0.3;L1=.1;L2=.2;L3= .3;L4= .4;L5= .5;L6=.6;L7= .7;
    Vmin=0.0;

    q1=q1Aexpression;
    q2=q2Aexpression;
    q3=q3Aexpression;
    q4=q4Aexpression;

    existQ=conditionA;

    if (existQ)
        {
            Vmin2=VAmin;
            Vmin=min(Vmin2,Vmin);
        }

    q1=q1Bexpression;
    q2=q2Bexpression;
    q3=q3Bexpression;
    q4=q4Bexpression;
    existQ=conditionB;

    if (existQ)
        {
            Vmin2=VBmin;
            Vmin=min(Vmin2,Vmin);
        }

    q1=q1Cexpression;
    q2=q2Cexpression;
    q3=q3Cexpression;
    q4=q4Cexpression;
    existQ=conditionC;

    if (existQ)
        {
            Vmin2=VCmin;
            Vmin=min(Vmin2,Vmin);
        }


    return Vmin;
}

#define m2_L_release\
    m112=m2_L[0];m122=m2_L[1];m222=m2_L[2];\
    L1=m2_L[3];L2=m2_L[4];L3=m2_L[5];\
    L4=m2_L[6];L5=m2_L[7];L6=0;\
    L7=0;

double ABCEminVec(vector<double> m2_L)
{
    double m112,m122,m222,L1,L2,L3,L4,L5,L6,L7;
    m2_L_release
    return ABCEmin(m112,m122,m222,L1,L2,L3,L4,L5,L6,L7);

}

vector<double> genBasis(double mh2,double mH2,double mA2,double mHc2,double m122,double v2,double alpha,double beta)
{
    double sb = sin(beta);
    double sa= sin(alpha);
    double cb= cos(beta);
    double ca= cos(alpha);
    vector<double> m2_L;

    double m112,m222,L1,L2,L3,L4,L5;
    L1=L1sol;
    L2=L2sol;
    L3=L3sol;
    L4=L4sol;
    L5=L5sol;
    m112=m112sol;
    //m122 alreay there
    m222=m222sol;


    m2_L.push_back(m112);
    m2_L.push_back(m122);
    m2_L.push_back(m222);
    m2_L.push_back(L1);
    m2_L.push_back(L2);
    m2_L.push_back(L3);
    m2_L.push_back(L4);
    m2_L.push_back(L5);

    return m2_L;

}

vector<double> read_binary(string path)
{
   ifstream fin(path, ios::binary);
   vector<double> v;
   double r;
    while (fin.read((char *) &r, sizeof(double))
           )
    {
        v.push_back(r);
    }
   return v;

}


int  write_binary(string path, vector<double> v)
{
    ofstream fout(path, std::ios::binary);

    fout.write((char *) &v[0], sizeof(double)*v.size());

    return 0;

}

double Vpotential(double phi11,double phi12r,double phi12i,double phi22,
                  vector<double> m2_L)
{
    double V;
    double m112,m122,m222,L1,L2,L3,L4,L5,L6,L7;
    m2_L_release
    V=Vexpression;
    return V;
}


int main()
{
    double mh2, mH2, mA2, mHc2, m122, v2, alpha, beta,cb,sb;
    double VminAna,VminGood;
    int index;
    vector<double> m2_L,Vmin_output,m2_L_output;
    vector<double> inputdata;
    cout<<"reading data...\n";
    string datapath="";
    inputdata=read_binary(datapath+"phys-input.double");
    cout<<"computing...\n";
    for (int i=0;i<inputdata.size();i=i+10){
        //cout<<i/8<<"\n";
        index=i+1;
        mh2=inputdata[index]; index++;
        mH2=inputdata[index]; index++;
        mA2=inputdata[index];index++;
        mHc2=inputdata[index];index++;
        m122=inputdata[index];index++;
        v2=inputdata[index];index++;
        alpha=inputdata[index];index++;
        beta=inputdata[index];index++;

        cb=cos(beta);
        sb=sin(beta);
        m2_L=genBasis(mh2, mH2, mA2, mHc2, m122, v2, alpha, beta);
        for (auto num: m2_L)
            m2_L_output.push_back(num);

        VminAna=ABCEminVec(m2_L);
        VminGood=Vpotential((pow(cb,2)*v2)/2.,
                            (cb*sb*v2)/2.,0,
                            (pow(sb,2)*v2)/2.,
                            m2_L);
        Vmin_output.push_back(VminAna);
        Vmin_output.push_back(VminGood);


    }

    write_binary(datapath+"Vmin.double",Vmin_output);
    write_binary(datapath+"m2_L.double",m2_L_output);

    for (auto i: m2_L)
        cout << i << ' ';
    cout << "Hello world!" << endl;
    return 0;
}

/*


int main()
{
    double m112,m122,m222,L1,L2,L3,L4,L5,L6,L7;
    double Vmin;

    ifstream input("input.csv");
	ofstream output;
	output.open ("output.csv");

    for (int i=0; ( !input.eof() ) ;i++){
        // cout << ".."<<i<<"\n";
        input >> m112;input >> m122;input >> m222;
        input >> L1;input >> L2;input >> L3;input >> L4;
        input >> L5;input >> L6;input >> L7;

        if ( !input.eof() ){
        Vmin=ABCEmin(m112,m122,m222,L1,L2,L3,L4,L5,L6,L7);
        output << Vmin<<"\n";
        }
    }

    output.close();

    cout << "Hello world!" << endl;
    return 0;
}

int main()
{
     cout << "Hello world!" << endl;

    double m112,m122,m222,L1,L2,L3,L4,L5,L6,L7;
    double Vmin;
    m112=0.1; m122=0.2;m222= 0.3;L1=.1;L2=.2;L3= .3;L4= .4;L5= .5;L6=.6;L7= .7;
    Vmin=ABCEmin(m112,m122,m222,L1,L2,L3,L4,L5,L6,L7);
    return 0;
}


int main()
{
    cout << "Hello world!" << endl;

    double q1,q2,q3,q4;
    double m112,m122,m222,L1,L2,L3,L4,L5,L6,L7;
    double Vmin,Vmin2;
    bool existQ;
    m112=0.1; m122=0.2;m222= 0.3;L1=.1;L2=.2;L3= .3;L4= .4;L5= .5;L6=.6;L7= .7;
    Vmin=0.0;

    q1=q1Aexpression;
    q2=q2Aexpression;
    q3=q3Aexpression;
    q4=q4Aexpression;

    existQ=conditionA;

    if (existQ)
        {
            Vmin2=VAmin;
            Vmin=min(Vmin2,Vmin);
        }

    q1=q1Bexpression;
    q2=q2Bexpression;
    q3=q3Bexpression;
    q4=q4Bexpression;
    existQ=conditionB;

    if (existQ)
        {
            Vmin2=VBmin;
            Vmin=min(Vmin2,Vmin);
        }

    q1=q1Cexpression;
    q2=q2Cexpression;
    q3=q3Cexpression;
    q4=q4Cexpression;
    existQ=conditionC;

    if (existQ)
        {
            Vmin2=VBmin;
            Vmin=min(Vmin2,Vmin);
        }

    cout<<q1<<q2<<q3<<q4 <<endl;


    return Vmin;
}
*/
